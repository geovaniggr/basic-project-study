import java.awt.Color;

public class FxShadow {
  private double cx;
  private double cy;
  private double size;
  private Color color;

  public FxShadow(double cx, double cy, double size, Color color){
    this.cx = cx;
    this.cy = cy;
    this.size = size;
    this.color = color.darker().darker();
  }

  public void draw(){
    GameLib.setColor(color);
    GameLib.fillRect(cx, cy, size, size);
    size -= 0.5;
  }

  public double getSize(){
    return size;
  }

}
